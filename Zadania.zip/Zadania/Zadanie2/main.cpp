#include <iostream>
#include <math.h>

using namespace std;

int main()
{
    //Program liczacy pole kola
    float w,r;
    cout << "Podaj promien kola" << endl;
    cin >> r;
    w = M_PI * pow(r,2);
    cout << "Wynik to:" << w << endl;
    return 0;
}
