#include <iostream>
#include <math.h>

using namespace std;

int main()
{
    float waga,wzrost,BMI;
    cout << "Podaj wzrost w metrach" << endl;
    cin >> wzrost;
    cout << "Podaj waga" << endl;
    cin >> waga;

    BMI = waga / pow(wzrost,2);
    cout << "Twoja waga wynosi:" << BMI << endl;
}
