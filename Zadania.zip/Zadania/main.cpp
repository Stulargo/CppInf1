#include <iostream>

using namespace std;

int main()
{
    //Napisz program liczacy srednia arytmetyczna 4 zmiennych


    float a,b,c,d;
    int s = 0;
    float w;
    cout << "Podaj 1 zmienna" << endl;
    cin >> a;
    s=s+1;
    cout << "Podaj 2 zmienna" << endl;
    cin >> b;
    s=s+1;
    cout << "Podaj 3 zmienna" << endl;
    cin >> c;
    s=s+1;
    cout << "Podaj 4 zmienna" << endl;
    cin >> d;
    s=s+1;
    w = (a+b+c+d)/s;
    cout << "Srednia wynosi:" << w <<endl;
    return 0;
}
