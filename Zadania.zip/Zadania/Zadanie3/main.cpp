#include <iostream>
#include <math.h>

using namespace std;

int main()
{
    int x,y;
    double w,r;
    cout << "Podaj x oraz y" << endl;
    cin >> x;
    cin >> y;
    w = pow(x,y);
    cout << "Wynik to:" << w << endl;
    return 0;
}
